INSERT INTO persona(nombre, apellido, edad, direccion) VALUES('Luis', 'Orellana', 24, 'carreca 20 n 15- 14');
INSERT INTO persona(nombre, apellido, edad, direccion) VALUES('Juan', 'Orellana', 24, 'carreca 20 n 15- 14');
INSERT INTO persona(nombre, apellido, edad, direccion) VALUES('Carlos', 'Orellana', 24, 'carreca 20 n 15- 14');
INSERT INTO persona(nombre, apellido, edad, direccion) VALUES('Andres', 'Orellana', 24, 'carreca 20 n 15- 14');
INSERT INTO persona(nombre, apellido, edad, direccion) VALUES('Cesar', 'Orellana', 24, 'carreca 20 n 15- 14');