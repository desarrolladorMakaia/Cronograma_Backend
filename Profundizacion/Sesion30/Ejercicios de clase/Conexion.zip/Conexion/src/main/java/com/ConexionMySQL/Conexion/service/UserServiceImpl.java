package com.ConexionMySQL.Conexion.service;

import com.ConexionMySQL.Conexion.entity.Persona;
import com.ConexionMySQL.Conexion.repository.PersonaRepositoryDao;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements PersonaService{

    private PersonaRepositoryDao personaRepositoryDao;

    @Override
    public List<Persona> getAll() {
        return null;
    }

    @Override
    public Persona findById(Long idAlumno) {
        return null;
    }

    @Override
    public Persona create(Persona persona) {
            return personaRepositoryDao.create(persona);
    }
}

