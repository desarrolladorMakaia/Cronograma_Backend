package com.ConexionMySQL.Conexion.repository;

import com.ConexionMySQL.Conexion.entity.Persona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
@Repository
public class PersonaRepositoryImpl implements PersonaRepositoryDao {


    @Autowired
    private PersonaRepo personaRepo;


    @Override
    public List<Persona> getAll() {
        List<Persona> userFound = new ArrayList<>();
        personaRepo.findAll().forEach(user -> userFound.add(user));
        return userFound;
    }

    @Override
    public Persona findById(Long idUser) {
        return personaRepo.findById(idUser).get();
    }


    @Override
    public Persona create(Persona persona) {
        return personaRepo.save(persona);
    }

}