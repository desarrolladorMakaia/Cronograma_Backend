package com.ConexionMySQL.Conexion.repository;

import com.ConexionMySQL.Conexion.entity.Persona;

import java.util.List;

public interface PersonaRepositoryDao {

    List<Persona> getAll();

    Persona findById(Long idUser);

    Persona create(Persona persona);
}

