package com.ConexionMySQL.Conexion.service;

import com.ConexionMySQL.Conexion.entity.Persona;

import java.util.List;

public interface PersonaService {

    List<Persona> getAll();
    Persona findById(Long idAlumno);
    Persona create(Persona persona);
}
