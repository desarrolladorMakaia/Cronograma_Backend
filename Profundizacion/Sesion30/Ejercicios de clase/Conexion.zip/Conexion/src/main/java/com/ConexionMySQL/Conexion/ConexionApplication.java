package com.ConexionMySQL.Conexion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.*;

@SpringBootApplication
public class ConexionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConexionApplication.class, args);

	}
}
