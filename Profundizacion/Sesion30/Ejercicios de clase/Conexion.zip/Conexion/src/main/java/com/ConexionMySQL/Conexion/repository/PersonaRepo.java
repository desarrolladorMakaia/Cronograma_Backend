package com.ConexionMySQL.Conexion.repository;

import com.ConexionMySQL.Conexion.entity.Persona;
import org.springframework.data.repository.CrudRepository;

public interface PersonaRepo extends CrudRepository <Persona, Long> {
}
