package com.ConexionMySQL.Conexion.controller;

import com.ConexionMySQL.Conexion.entity.Persona;
import com.ConexionMySQL.Conexion.service.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1/personas")
public class PersonaController {

    private final PersonaService personaService;

    @Autowired
    public PersonaController(PersonaService personaService) {
        this.personaService = personaService;
    }

    @PostMapping
    public ResponseEntity<Persona> createUser(@RequestBody Persona persona) {
        Optional<Persona> personaValidation = Optional.ofNullable(personaService.create(persona));
        if (personaValidation != null) {
            return new ResponseEntity("Created person!", HttpStatus.CREATED);
        }
        return new ResponseEntity("person not created!", HttpStatus.BAD_REQUEST);
    }
}
