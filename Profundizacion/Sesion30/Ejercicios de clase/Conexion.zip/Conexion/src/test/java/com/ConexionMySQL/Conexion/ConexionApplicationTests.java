package com.ConexionMySQL.Conexion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConexionApplicationTests {

	@Test
	void contextLoads() {
	}

}
