package org.jugnicaragua.demo.dao.entity;

/**
 * El sistema de tipos en GraphQL es el componente más básico y representa un tipo de objeto que
 * se puede obtener de un servicio y los campos que contiene el objeto.
 */

//TODO La anotación @EqualsAndHashCode es una anotación de Lombok en Java que se utiliza para
// generar automáticamente los métodos equals() y hashCode() en una clase. Estos métodos se
// utilizan comúnmente en Java para comparar objetos y determinar si son iguales. La anotación
// genera un método equals() que compara los campos de la clase y un método hashCode() que calcula
// un valor de hash para el objeto en función de sus campos. Esto simplifica el código y evita tener
// que escribir manualmente estos métodos.

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Data
@EqualsAndHashCode
@Entity
public class Vehicle implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "type", nullable = false)
    private String type;

    @Column(name = "model_code", nullable = false)
    private String modelCode;

    @Column(name = "brand_name")
    private String brandName;

    @Column(name = "launch_date")
    private LocalDate launchDate;

    private String color;
    private String altura;
    private Double ancho;
    private Double largo;

    private transient String formattedDate;

    // Getter and setter
    public String getFormattedDate() {
        return getLaunchDate().toString();
    }

}