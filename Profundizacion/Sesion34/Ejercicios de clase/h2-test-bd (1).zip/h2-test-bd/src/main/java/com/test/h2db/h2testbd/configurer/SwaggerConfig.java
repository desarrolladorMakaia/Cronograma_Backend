package com.test.h2db.h2testbd.configurer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

    @Configuration
    @EnableSwagger2
    public class SwaggerConfig {

        @Bean
        Docket api() {
            return new Docket(DocumentationType.SWAGGER_2).select()
                    .apis(RequestHandlerSelectors.withClassAnnotation(RestController.class)).paths(PathSelectors.any())
                    .build();
        }
    }

     //@Configuration: esta anotación indica que la clase es una configuración de Spring, lo que significa que contiene
     // métodos de configuración de Spring. En este caso, la clase SwaggerConfig contiene la configuración de Swagger.

     //@EnableSwagger2: esta anotación indica que se habilita la integración de Swagger en la aplicación.

     //public class SwaggerConfig: esta es la definición de la clase SwaggerConfig, que contiene la configuración de Swagger.

     //   @Bean: esta anotación indica que el método api() es un método que crea y configura un objeto que se puede utilizar
     //  en la aplicación de Spring.

       // Docket: esta es la clase principal de Swagger que se utiliza para crear un objeto que contiene la configuración de Swagger.

      //  DocumentationType.SWAGGER_2: esta línea indica que se está utilizando la versión 2 de Swagger.

       // .select(): este método devuelve una instancia de ApiSelectorBuilder, que se utiliza para seleccionar
      //  qué APIs se incluirán en la documentación de Swagger.

     //   .apis(RequestHandlerSelectors.withClassAnnotation(RestController.class)): este método selecciona todas las APIs
     //   que se han definido en las clases anotadas con @RestController.

      // .paths(PathSelectors.any()): este método indica que todas las rutas de la API se deben incluir en la documentación de Swagger.

      //  .build(): este método construye y devuelve el objeto Docket configurado.

     //   En resumen, este código configura Swagger en una aplicación de Spring Boot para que la documentación de Swagger
        //        incluya todas las rutas de la API definidas en las clases anotadas con @RestController.

   //1. Agregar la dependendencia al pom.xml
   //     https://mvnrepository.com/artifact/io...

   //     Nota: No olvidar realizar un clic derecho al proyecto -  Maven - Update Project

     //   2. Agregar en el application.properties
     //   spring.mvc.pathmatch.matching-strategy=ant-path-matcher

    //    3. Crear la clase SwaggerConfig


   //4. Iniciar la aplicación e ir a:
     //   http://localhost:8080/swagger-ui/index.html



