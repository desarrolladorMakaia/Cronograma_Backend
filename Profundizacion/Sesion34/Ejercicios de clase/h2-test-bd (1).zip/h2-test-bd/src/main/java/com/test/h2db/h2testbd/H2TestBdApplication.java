package com.test.h2db.h2testbd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2TestBdApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2TestBdApplication.class, args);
	}

}
