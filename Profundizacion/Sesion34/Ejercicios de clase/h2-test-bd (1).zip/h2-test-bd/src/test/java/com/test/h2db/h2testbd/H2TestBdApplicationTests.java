package com.test.h2db.h2testbd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2TestBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
