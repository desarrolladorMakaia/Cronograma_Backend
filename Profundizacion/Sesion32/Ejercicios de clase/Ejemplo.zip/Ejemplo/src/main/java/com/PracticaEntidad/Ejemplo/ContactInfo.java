package com.PracticaEntidad.Ejemplo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor

@Entity
@Table(name = "contact_info")
public class ContactInfo {

    @Id
    @Column (name = "student_id")
    private Long id;

    @Column (name = "email" , nullable = false)
    private String email;

    @Column (name = "email" , nullable = false)
    private String phone;

    @Column (name = "address" , nullable = false)
    private String address;

    @Column (name = "city" , nullable = false)
    private String city;

    @Column (name = "state" , nullable = false)
    private String state;
    @Column (name = "zip" , nullable = false)
    private String zip;

    @OneToOne(cascade = CascadeType.ALL, optional = false)
    @MapsId
    @JoinColumn(name = "student_id")
    private Student student;



    public ContactInfo(Long id, String email, String phone, String address, String city, String state, String zip) {
        this.id = id;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }

    @Override
    public String toString() {
        return "ContactInfo{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zip='" + zip + '\'' +
                '}';
    }
}
